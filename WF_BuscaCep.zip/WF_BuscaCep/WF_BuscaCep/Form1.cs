﻿using Correios.Net;
using System;
using System.Windows.Forms;

namespace WF_BuscaCep
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnEncerrar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void textCep_Leave(object sender, EventArgs e)
        {
            LocalizarCEP();
        }

        private void LocalizarCEP()
        {

            if (!string.IsNullOrWhiteSpace(txtCep.Text))
            {
                Address endereco = SearchZip.GetAddress(txtCep.Text);

                if (endereco.Zip != null)
                {

                    txtEstado.Text = endereco.State;
                    txtCidade.Text = endereco.City;
                    txtBairro.Text = endereco.District;
                    txtRua.Text = endereco.Street;
                }
                else
                {
                    MessageBox.Show("Cep não localizado...");
                }
            }
            else
            {
                MessageBox.Show("Informe um CEP válido");
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            foreach (var c in this.Controls)
            {
                if (c is TextBox)
                {
                    ((TextBox)c).Text = String.Empty;
                }
            }
        }

        private void txtCep_Enter(object sender, EventArgs e)
        {
            TextBox TB = (TextBox)sender;
            int VisibleTime = 1000;  //milisegundos

            ToolTip tt = new ToolTip();
            tt.Show("Digite o CEP sem espaços ou traços...", TB, 0, 0, VisibleTime);
        }
    }
}
